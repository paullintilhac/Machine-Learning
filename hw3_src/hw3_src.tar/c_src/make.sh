#!/bin/bash

g++ -std=gnu++11 -o hw3.out hw3.cpp

./hw3.out
